# -*- coding: utf-8 -*-
"""
Terrain Analysis and Hydrological Modeling — QGIS plugin.

Реализует полную цепочку индексной GIS-модели эрозионной опасности:

    DEM -> Slope/Aspect/Hillshade/TPI -> sun_aspect, flow
        -> water_retention (W), drying_model (D)
        -> new_erosion (E)

Формулы модели:
    Sn     = slope / 90
    I_sun  = (1 + cos((aspect - 180) * pi/180)) / 2      # юг = 1, север = 0
    Fn     = нормированная аккумуляция стока (log-шкала для SAGA/GRASS)
    K+n    = нормированная вогнутость (max(0, -TPI))
    W      = 0.35*Fn + 0.25*K+n + 0.20*(1-Sn) + 0.20*(1-I_sun)
    D      = 0.35*I_sun + 0.25*Sn + 0.20*(1-Fn) + 0.20*(1-K+n)
    E      = wS*Sn + wD*Dn + wW*(1-Wn) + wP*(1-P)         # веса настраиваются в UI

Сток считается встроенным движком (flow_engine.py) без SAGA/GRASS:
вода распределяется по нескольким приоритетным направлениям
(D4 / D8 / шестигранная сетка), с опциональным ограничением числа
шагов по времени.

Все тяжёлые расчёты выполняются в фоне через QgsTask, интерфейс QGIS
не блокируется, задачу можно отменить.
"""
import os
import math
import shutil
import tempfile

from qgis.core import (QgsProject, QgsRasterLayer, QgsVectorLayer,
                       QgsMessageLog, Qgis, QgsRasterBandStats,
                       QgsTask, QgsApplication, QgsProcessingFeedback,
                       QgsCoordinateReferenceSystem,
                       QgsSingleBandPseudoColorRenderer, QgsColorRampShader,
                       QgsRasterShader)
from qgis.PyQt.QtGui import QColor
from qgis.PyQt.QtWidgets import (QAction, QDialog, QVBoxLayout, QHBoxLayout,
                                 QLabel, QLineEdit, QPushButton, QFileDialog,
                                 QTabWidget, QWidget, QCheckBox, QComboBox,
                                 QProgressBar, QMessageBox, QDoubleSpinBox,
                                 QSpinBox, QFormLayout, QGroupBox)
import processing

from .flow_engine import compute_flow_accumulation

# Qt6 (QGIS 4) перенёс константы кнопок в QMessageBox.StandardButton.
# Эти псевдонимы работают в обеих версиях Qt.
try:
    _Yes    = QMessageBox.StandardButton.Yes
    _No     = QMessageBox.StandardButton.No
    _Cancel = QMessageBox.StandardButton.Cancel
except AttributeError:          # Qt5 / QGIS 3
    _Yes    = _Yes
    _No     = _No
    _Cancel = _Cancel

PLUGIN_LOG_TAG = "Terrain & Hydrology"
PLUGIN_VERSION = "2.0"

# соответствие пунктов UI внутренним кодам топологии
FLOW_TOPOLOGIES = [
    ("D8 — 8 направлений", "d8"),
    ("D4 — 4 направления", "d4"),
    ("Шестигранная сетка — 6 направлений", "hex"),
]


# ======================================================================
#  Плагин: регистрация в QGIS
# ======================================================================

class TerrainHydrologyPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.action = None
        self.about_action = None
        self.window = None

    def initGui(self):
        icon_path = os.path.join(os.path.dirname(__file__), "icon.png")
        from qgis.PyQt.QtGui import QIcon
        icon = QIcon(icon_path) if os.path.exists(icon_path) else QIcon()

        self.action = QAction(icon, "Terrain && Hydrology Analysis",
                              self.iface.mainWindow())
        self.action.triggered.connect(self.run)
        self.iface.addRasterToolBarIcon(self.action)
        self.iface.addPluginToRasterMenu("Terrain && Hydrology", self.action)

        self.about_action = QAction("О плагине / About",
                                    self.iface.mainWindow())
        self.about_action.triggered.connect(self.show_about)
        self.iface.addPluginToRasterMenu("Terrain && Hydrology",
                                         self.about_action)

    def unload(self):
        if self.window:
            self.window.cancel_running_task()
            self.window.close()
            self.window = None
        if self.action:
            self.iface.removeRasterToolBarIcon(self.action)
            self.iface.removePluginRasterMenu("Terrain && Hydrology",
                                              self.action)
        if self.about_action:
            self.iface.removePluginRasterMenu("Terrain && Hydrology",
                                              self.about_action)

    def run(self):
        if not self.window:
            self.window = MainWindow(self.iface)
        self.window.show()
        self.window.raise_()
        self.window.activateWindow()

    def show_about(self):
        QMessageBox.about(
            self.iface.mainWindow(),
            "Terrain & Hydrology Analysis",
            f"<b>Terrain Analysis and Hydrological Modeling</b> v{PLUGIN_VERSION}"
            "<p>Учебный плагин: строит слои рельефа и полную индексную "
            "модель эрозионной опасности:</p>"
            "<p><i>E = w<sub>S</sub>·S<sub>n</sub> + w<sub>D</sub>·D<sub>n</sub> "
            "+ w<sub>W</sub>·(1−W<sub>n</sub>) + w<sub>P</sub>·(1−P)</i></p>"
            "<p>Модель является упрощённой пространственной оценкой и не "
            "заменяет инженерно-геологические изыскания.</p>"
            "<p>Educational plugin implementing an index-based erosion "
            "vulnerability model on top of GDAL/SAGA/GRASS providers.</p>")


# ======================================================================
#  Фоновая задача расчёта (QgsTask)
# ======================================================================

class AnalysisTask(QgsTask):
    """
    Выполняет все вызовы processing.run в фоновом потоке.
    Загрузку слоёв на карту делает MainWindow в finished() —
    работа с QgsProject разрешена только в главном потоке.
    """

    def __init__(self, description, dem, out_dir, options):
        super().__init__(description, QgsTask.CanCancel)
        self.dem = dem
        self.out_dir = out_dir
        self.opt = options            # словарь всех настроек из UI
        self.feedback = QgsProcessingFeedback()
        self.generated_layers = []    # [(path, name, style_key)]
        self.warnings = []
        self.exception = None
        self._tmp = None

    # ---------------- вспомогательные методы ----------------

    def _log(self, msg, level=Qgis.Info):
        QgsMessageLog.logMessage(msg, PLUGIN_LOG_TAG, level)

    def _minmax(self, raster_path):
        layer = QgsRasterLayer(raster_path, "tmp_stats")
        stats = layer.dataProvider().bandStatistics(
            1, QgsRasterBandStats.Min | QgsRasterBandStats.Max)
        return float(stats.minimumValue), float(stats.maximumValue)

    def _run(self, alg_id, params):
        """processing.run с общим feedback (поддержка отмены)."""
        return processing.run(alg_id, params, feedback=self.feedback)

    def _calc(self, formula, out_file, **rasters):
        """Обёртка над gdal:rastercalculator (Float32)."""
        params = {'FORMULA': formula, 'RTYPE': 5, 'OUTPUT': out_file,
                  'NO_DATA': -9999}
        for letter, path in rasters.items():   # a='...', b='...'
            params[f'INPUT_{letter.upper()}'] = path
            params[f'BAND_{letter.upper()}'] = 1
        self._run("gdal:rastercalculator", params)
        return out_file

    def _normalize(self, src, dst, log_scale=False):
        """Приводит растр к диапазону 0–1 по фактическим min/max."""
        vmin, vmax = self._minmax(src)
        if log_scale and vmax > 0:
            # log-нормировка для сильно скошенных распределений
            # (реальная аккумуляция стока)
            shift = max(0.0, -vmin)
            denom = math.log10(1.0 + vmax + shift) or 1.0
            formula = f"log10(1.0 + A + {shift}) / {denom}"
        else:
            vrange = (vmax - vmin) or 1.0
            formula = f"(A - {vmin}) / {vrange}"
        return self._calc(formula, dst, a=src)

    def _flow_accumulation(self, dem, out_file):
        """
        Аккумуляция стока встроенным движком (flow_engine):
        несколько приоритетных направлений, топология D4/D8/hex,
        опциональное ограничение по времени (числу шагов).
        """
        o = self.opt
        compute_flow_accumulation(
            dem, out_file,
            topology=o['flow_topology'],
            k_priority=o['flow_k'],
            time_steps=o['flow_time_steps'],
            progress_cb=None)   # прогресс шага виден по общему прогрессу
        t = o['flow_time_steps']
        self._log(
            f"Сток рассчитан: топология {o['flow_topology']}, "
            f"приоритетных направлений: {o['flow_k'] or 'все'}, "
            f"время: {'до полного стекания' if t == 0 else str(t) + ' шаг(ов)'}.",
            Qgis.Success)
        return True

    # ---------------- основной расчёт ----------------

    def run(self):
        self._tmp = tempfile.mkdtemp(prefix="terrain_hydro_")
        o = self.opt
        try:
            steps = list(o['tasks'])
            total = len(steps) + (4 if "Erosion" in steps else 0)
            done = 0

            def tick():
                nonlocal done
                done += 1
                self.setProgress(min(99, int(done / total * 100)))
                return not self.isCanceled()

            dem = self.dem
            tmp = self._tmp
            out = self.out_dir
            paths = {}   # промежуточные растры для эрозионной цепочки

            # ---------- базовые слои ----------
            if "Hillshade" in steps:
                f = os.path.join(out, "hillshade.tif")
                self._run("gdal:hillshade", {
                    'INPUT': dem, 'BAND': 1,
                    'AZIMUTH': o['hs_azimuth'], 'ALTITUDE': o['hs_altitude'],
                    'SCALE': 1, 'MULTIDIRECTIONAL': o['hs_multi'],
                    'OUTPUT': f})
                self.generated_layers.append((f, "Отмывка (Hillshade)", None))
                if not tick():
                    return False

            need_slope = ("Slope" in steps) or ("Erosion" in steps)
            if need_slope:
                f = (os.path.join(out, "slope.tif") if "Slope" in steps
                     else os.path.join(tmp, "slope.tif"))
                self._run("gdal:slope", {
                    'INPUT': dem, 'BAND': 1, 'SCALE': 1,
                    'AS_PERCENT': False, 'COMPUTE_EDGES': True,
                    'ZEVENBERGEN': False, 'OUTPUT': f})
                paths['slope'] = f
                if "Slope" in steps:
                    self.generated_layers.append((f, "Уклон (Slope)", "slope"))
                    if not tick():
                        return False

            need_aspect = ("Aspect" in steps) or ("Erosion" in steps)
            if need_aspect:
                f = (os.path.join(out, "aspect.tif") if "Aspect" in steps
                     else os.path.join(tmp, "aspect.tif"))
                self._run("gdal:aspect", {
                    'INPUT': dem, 'BAND': 1, 'TRIGONOMETRIC': False,
                    'ZERO_FLAT': True, 'COMPUTE_EDGES': True, 'OUTPUT': f})
                paths['aspect'] = f
                if "Aspect" in steps:
                    self.generated_layers.append(
                        (f, "Экспозиция (Aspect)", None))
                    if not tick():
                        return False

            if "Contours" in steps:
                f = os.path.join(out, "contours.gpkg")
                self._run("gdal:contour", {
                    'INPUT': dem, 'BAND': 1,
                    'INTERVAL': o['contour_interval'],
                    'FIELD_NAME': 'ELEV', 'OFFSET': 0, 'OUTPUT': f})
                self.generated_layers.append(
                    (f, f"Горизонтали ({o['contour_interval']} м)", None))
                if not tick():
                    return False

            # ---------- сток (встроенный движок) ----------
            need_flow = ("Runoff" in steps) or ("Erosion" in steps)
            if need_flow:
                f = (os.path.join(out, "flow_accumulation.tif")
                     if "Runoff" in steps
                     else os.path.join(tmp, "flow.tif"))
                self._flow_accumulation(dem, f)
                paths['flow'] = f
                if "Runoff" in steps:
                    t = o['flow_time_steps']
                    time_part = ("" if t == 0
                                 else f", T={t} шаг.")
                    topo_label = {"d8": "D8", "d4": "D4",
                                  "hex": "hex-6"}[o['flow_topology']]
                    name = (f"Аккумуляция стока ({topo_label}, "
                            f"k={o['flow_k'] or 'все'}{time_part})")
                    self.generated_layers.append((f, name, "flow"))
                    if not tick():
                        return False

            # ---------- полная эрозионная цепочка ----------
            if "Erosion" in steps:
                # 1. Нормированные факторы
                s_n = self._calc("A / 90.0",
                                 os.path.join(tmp, "s_n.tif"),
                                 a=paths['slope'])
                if not tick():
                    return False

                # sun_aspect: I_sun = (1 + cos((aspect-180)°)) / 2
                i_sun = self._calc(
                    "(1.0 + cos((A - 180.0) * 0.0174532925)) / 2.0",
                    os.path.join(out, "sun_aspect.tif"),
                    a=paths['aspect'])
                self.generated_layers.append(
                    (i_sun, "Индекс солнечного воздействия (sun_aspect)",
                     "sun"))
                if not tick():
                    return False

                f_n = self._normalize(paths['flow'],
                                      os.path.join(tmp, "f_n.tif"),
                                      log_scale=True)

                # K+n — вогнутость из TPI
                tpi2 = os.path.join(tmp, "tpi2.tif")
                self._run("gdal:tpitopographicpositionindex", {
                    'INPUT': dem, 'BAND': 1, 'COMPUTE_EDGES': True,
                    'OUTPUT': tpi2})
                k_raw = self._calc("maximum(0.0, -A)",
                                   os.path.join(tmp, "k_raw.tif"), a=tpi2)
                k_n = self._normalize(k_raw, os.path.join(tmp, "k_n.tif"))
                if not tick():
                    return False

                # 2. water_retention:
                #    W = 0.35 Fn + 0.25 K+n + 0.20 (1-Sn) + 0.20 (1-Isun)
                w_file = self._calc(
                    "0.35*A + 0.25*B + 0.20*(1.0-C) + 0.20*(1.0-D)",
                    os.path.join(out, "water_retention.tif"),
                    a=f_n, b=k_n, c=s_n, d=i_sun)
                self.generated_layers.append(
                    (w_file, "Удержание влаги (water_retention)", "water"))

                # 3. drying_model:
                #    D = 0.35 Isun + 0.25 Sn + 0.20 (1-Fn) + 0.20 (1-K+n)
                d_file = self._calc(
                    "0.35*A + 0.25*B + 0.20*(1.0-C) + 0.20*(1.0-D)",
                    os.path.join(out, "drying_model.tif"),
                    a=i_sun, b=s_n, c=f_n, d=k_n)
                self.generated_layers.append(
                    (d_file, "Высыхание (drying_model)", "dry"))
                if not tick():
                    return False

                # 4. Нормируем W и D (уже почти 0-1, но приводим строго)
                w_n = self._normalize(w_file, os.path.join(tmp, "w_n.tif"))
                d_n = self._normalize(d_file, os.path.join(tmp, "d_n.tif"))

                # 5. Защитный фактор P
                if o['protection_raster']:
                    p_n = self._normalize(
                        o['protection_raster'],
                        os.path.join(tmp, "p_n.tif"))
                    p_note = "P: пользовательский растр"
                else:
                    p_n = self._calc("A*0.0 + 0.5",
                                     os.path.join(tmp, "p_n.tif"), a=s_n)
                    p_note = "P: константа 0.5 (защитный растр не задан)"
                    self.warnings.append(
                        "Защитный растр не задан — использован P = 0.5.")

                # 6. Итог: E = wS*Sn + wD*Dn + wW*(1-Wn) + wP*(1-P)
                wS, wD, wW, wP = (o['w_slope'], o['w_dry'],
                                  o['w_wet'], o['w_prot'])
                e_file = self._calc(
                    f"{wS}*A + {wD}*B + {wW}*(1.0-C) + {wP}*(1.0-D)",
                    os.path.join(out, "new_erosion.tif"),
                    a=s_n, b=d_n, c=w_n, d=p_n)
                self.generated_layers.append(
                    (e_file,
                     f"Эрозионная опасность E "
                     f"({wS:.2f}/{wD:.2f}/{wW:.2f}/{wP:.2f})",
                     "erosion"))
                self._log(f"Эрозионная модель готова. {p_note}", Qgis.Success)
                if not tick():
                    return False

            self.setProgress(100)
            return True

        except Exception as e:
            self.exception = e
            return False

    def finished(self, result):
        # выполняется в главном потоке — здесь можно трогать QgsProject.
        # Реальную загрузку делает MainWindow через сигнал taskCompleted,
        # но подчистить временную папку удобно тут.
        if self._tmp and os.path.isdir(self._tmp):
            shutil.rmtree(self._tmp, ignore_errors=True)

    def cancel(self):
        self.feedback.cancel()
        super().cancel()


# ======================================================================
#  Символика результатов
# ======================================================================

def apply_style(layer, style_key):
    """Назначает информативную цветовую схему вместо серого градиента."""
    if not isinstance(layer, QgsRasterLayer) or style_key is None:
        return

    stats = layer.dataProvider().bandStatistics(
        1, QgsRasterBandStats.Min | QgsRasterBandStats.Max)
    vmin, vmax = stats.minimumValue, stats.maximumValue

    def items(stops):
        return [QgsColorRampShader.ColorRampItem(v, QColor(c), lbl)
                for v, c, lbl in stops]

    discrete = False
    if style_key == "erosion":
        discrete = True
        stops = [(0.2, "#ffffb2", "очень низкая (0–0.2)"),
                 (0.4, "#fecc5c", "низкая (0.2–0.4)"),
                 (0.6, "#fd8d3c", "средняя (0.4–0.6)"),
                 (0.8, "#f03b20", "высокая (0.6–0.8)"),
                 (1.0, "#bd0026", "очень высокая (0.8–1.0)")]
    elif style_key == "water":
        stops = [(vmin, "#f7fbff", f"{vmin:.2f}"),
                 ((vmin + vmax) / 2, "#6baed6", ""),
                 (vmax, "#08306b", f"{vmax:.2f}")]
    elif style_key == "dry":
        stops = [(vmin, "#ffffcc", f"{vmin:.2f}"),
                 ((vmin + vmax) / 2, "#fd8d3c", ""),
                 (vmax, "#bd0026", f"{vmax:.2f}")]
    elif style_key == "sun":
        stops = [(0.0, "#2c458c", "север (мин. прогрев)"),
                 (0.5, "#f7f7f7", ""),
                 (1.0, "#e6842c", "юг (макс. прогрев)")]
    elif style_key == "slope":
        stops = [(0.0, "#ffffff", "0°"),
                 (15.0, "#fdae6b", "15°"),
                 (30.0, "#e6550d", "30°"),
                 (max(45.0, vmax), "#7f2704", "крутые")]
    elif style_key == "flow":
        stops = [(vmin, "#ffffff", ""),
                 (vmax, "#08519c", "макс. концентрация")]
    else:
        return

    shader_fn = QgsColorRampShader()
    shader_fn.setColorRampType(QgsColorRampShader.Discrete if discrete
                               else QgsColorRampShader.Interpolated)
    shader_fn.setColorRampItemList(items(stops))
    shader = QgsRasterShader()
    shader.setRasterShaderFunction(shader_fn)
    renderer = QgsSingleBandPseudoColorRenderer(
        layer.dataProvider(), 1, shader)
    layer.setRenderer(renderer)
    layer.triggerRepaint()


# ======================================================================
#  Главное окно
# ======================================================================

class MainWindow(QDialog):
    def __init__(self, iface, parent=None):
        super(MainWindow, self).__init__(parent or iface.mainWindow())
        self.iface = iface
        self.task = None
        self.init_ui()

    # ---------------- UI ----------------

    def init_ui(self):
        self.setWindowTitle("Terrain Analysis and Hydrological Modeling")
        self.setMinimumWidth(600)
        self.resize(600, 560)

        main_layout = QVBoxLayout()
        main_layout.setSpacing(10)

        # --- входные данные ---
        input_group = QVBoxLayout()

        input_group.addWidget(QLabel("Входная ЦМР (DEM):"))
        dem_layout = QHBoxLayout()
        self.dem_path = QLineEdit()
        self.dem_path.setPlaceholderText("Выберите растровый файл DEM...")
        btn_browse_dem = QPushButton("Обзор...")
        btn_browse_dem.clicked.connect(self.browse_dem)
        dem_layout.addWidget(self.dem_path)
        dem_layout.addWidget(btn_browse_dem)
        input_group.addLayout(dem_layout)

        input_group.addWidget(QLabel("Выходная папка:"))
        out_layout = QHBoxLayout()
        self.out_dir = QLineEdit()
        self.out_dir.setPlaceholderText(
            "Выберите папку для сохранения результатов...")
        btn_browse_out = QPushButton("Обзор...")
        btn_browse_out.clicked.connect(self.browse_output)
        out_layout.addWidget(self.out_dir)
        out_layout.addWidget(btn_browse_out)
        input_group.addLayout(out_layout)

        main_layout.addLayout(input_group)

        # --- вкладки ---
        self.tabs = QTabWidget()

        # Вкладка 1: Рельеф
        self.tab_terrain = QWidget()
        t_layout = QVBoxLayout()
        self.cb_hillshade = QCheckBox("Теневая отмывка (Hillshade)")
        self.cb_slope = QCheckBox("Уклон поверхности (Slope)")
        self.cb_aspect = QCheckBox("Экспозиция склонов (Aspect)")
        self.cb_contours = QCheckBox("Изогипсы / Горизонтали (Contours)")
        self.cb_slope.setChecked(True)
        self.cb_hillshade.setChecked(True)
        for cb in (self.cb_hillshade, self.cb_slope,
                   self.cb_aspect, self.cb_contours):
            t_layout.addWidget(cb)

        t_params = QFormLayout()
        self.spin_contour = QSpinBox()
        self.spin_contour.setRange(1, 500)
        self.spin_contour.setValue(10)
        self.spin_contour.setSuffix(" м")
        t_params.addRow("Интервал горизонталей:", self.spin_contour)

        self.spin_azimuth = QSpinBox()
        self.spin_azimuth.setRange(0, 360)
        self.spin_azimuth.setValue(315)
        self.spin_azimuth.setSuffix("°")
        t_params.addRow("Азимут освещения (hillshade):", self.spin_azimuth)

        self.spin_altitude = QSpinBox()
        self.spin_altitude.setRange(1, 90)
        self.spin_altitude.setValue(45)
        self.spin_altitude.setSuffix("°")
        t_params.addRow("Высота солнца (hillshade):", self.spin_altitude)

        self.cb_hs_multi = QCheckBox("Мультинаправленная отмывка")
        t_params.addRow("", self.cb_hs_multi)
        t_layout.addLayout(t_params)
        t_layout.addStretch()
        self.tab_terrain.setLayout(t_layout)

        # Вкладка 2: Гидрология и эрозия
        self.tab_hydrology = QWidget()
        h_layout = QVBoxLayout()
        self.cb_runoff = QCheckBox(
            "Потенциальные линии стока (Potential Runoff)")
        self.cb_erosion = QCheckBox(
            "Полная эрозионная модель (sun_aspect, W, D, E)")
        self.cb_erosion.setChecked(True)
        h_layout.addWidget(self.cb_runoff)
        h_layout.addWidget(self.cb_erosion)

        weights_box = QGroupBox(
            "Веса итоговой модели  E = wS·Sn + wD·Dn + wW·(1−Wn) + wP·(1−P)")
        w_form = QFormLayout()

        def make_weight(value):
            sb = QDoubleSpinBox()
            sb.setRange(0.0, 1.0)
            sb.setSingleStep(0.05)
            sb.setDecimals(2)
            sb.setValue(value)
            return sb

        self.w_slope = make_weight(0.40)
        self.w_dry = make_weight(0.25)
        self.w_wet = make_weight(0.20)
        self.w_prot = make_weight(0.15)
        w_form.addRow("wS — уклон:", self.w_slope)
        w_form.addRow("wD — высыхание:", self.w_dry)
        w_form.addRow("wW — (1 − удержание влаги):", self.w_wet)
        w_form.addRow("wP — (1 − защитный фактор):", self.w_prot)
        weights_box.setLayout(w_form)
        h_layout.addWidget(weights_box)

        h_layout.addWidget(QLabel(
            "Защитный растр P (опционально, напр. vegetation_protection):"))
        p_layout = QHBoxLayout()
        self.protection_path = QLineEdit()
        self.protection_path.setPlaceholderText(
            "Пусто = P принимается равным 0.5")
        btn_browse_p = QPushButton("Обзор...")
        btn_browse_p.clicked.connect(self.browse_protection)
        p_layout.addWidget(self.protection_path)
        p_layout.addWidget(btn_browse_p)
        h_layout.addLayout(p_layout)

        h_layout.addStretch()
        self.tab_hydrology.setLayout(h_layout)

        # Вкладка 3: Расширенные (модель стока)
        self.tab_advanced = QWidget()
        a_layout = QVBoxLayout()

        flow_box = QGroupBox("Модель водного слоя (встроенный движок)")
        flow_form = QFormLayout()

        self.combo_flow = QComboBox()
        for label, _code in FLOW_TOPOLOGIES:
            self.combo_flow.addItem(label)
        flow_form.addRow("Топология соседства:", self.combo_flow)

        self.spin_flow_k = QSpinBox()
        self.spin_flow_k.setRange(0, 8)
        self.spin_flow_k.setValue(3)
        self.spin_flow_k.setSpecialValueText("все нижележащие")
        flow_form.addRow("Приоритетных направлений:", self.spin_flow_k)

        self.spin_time_steps = QSpinBox()
        self.spin_time_steps.setRange(0, 10000)
        self.spin_time_steps.setValue(0)
        self.spin_time_steps.setSpecialValueText("до полного стекания")
        flow_form.addRow("Шагов по времени (T):", self.spin_time_steps)

        flow_box.setLayout(flow_form)
        a_layout.addWidget(flow_box)

        flow_hint = QLabel(
            "Вода из каждой ячейки распределяется по k самым крутым\n"
            "нижележащим направлениям выбранной топологии.\n"
            "T ограничивает время: 1 шаг = 1 переход между ячейками;\n"
            "малое T показывает картину стока вскоре после осадков.\n"
            "Шестигранная сетка аппроксимируется сдвигом чётных/нечётных\n"
            "строк растра (odd-r смещение).")
        flow_hint.setStyleSheet("color: #888; font-size: 10px;")
        a_layout.addWidget(flow_hint)

        a_layout.addStretch()
        self.tab_advanced.setLayout(a_layout)

        self.tabs.addTab(self.tab_terrain, "Рельеф (Terrain)")
        self.tabs.addTab(self.tab_hydrology, "Гидрология и эрозия")
        self.tabs.addTab(self.tab_advanced, "Расширенные (Advanced)")
        main_layout.addWidget(self.tabs)

        # --- нижняя панель ---
        bottom_layout = QHBoxLayout()
        self.progress_bar = QProgressBar()
        self.progress_bar.setValue(0)
        self.progress_bar.setVisible(False)
        self.status_label = QLabel("Статус: Готов")

        self.btn_run = QPushButton("Запустить анализ")
        self.btn_run.setStyleSheet(
            "background-color: #2e7d32; color: white; "
            "font-weight: bold; padding: 5px 15px;")
        self.btn_run.clicked.connect(self.on_run_clicked)

        bottom_layout.addWidget(self.status_label)
        bottom_layout.addWidget(self.progress_bar)
        bottom_layout.addStretch()
        bottom_layout.addWidget(self.btn_run)
        main_layout.addLayout(bottom_layout)
        self.setLayout(main_layout)

    # ---------------- обзор файлов ----------------

    def browse_dem(self):
        file_filter = "Raster Files (*.tif *.tiff *.img *.dem);;All Files (*)"
        filename, _ = QFileDialog.getOpenFileName(
            self, "Выберите входной файл DEM", "", file_filter)
        if filename:
            self.dem_path.setText(filename)

    def browse_output(self):
        dir_path = QFileDialog.getExistingDirectory(
            self, "Выберите папку для сохранения результатов")
        if dir_path:
            self.out_dir.setText(dir_path)

    def browse_protection(self):
        file_filter = "Raster Files (*.tif *.tiff *.img);;All Files (*)"
        filename, _ = QFileDialog.getOpenFileName(
            self, "Выберите защитный растр (P)", "", file_filter)
        if filename:
            self.protection_path.setText(filename)

    # ---------------- pre-flight проверки ----------------

    def preflight_dem(self, dem_path):
        """
        Проверяет DEM перед расчётом:
        - слой читается;
        - CRS не географическая (иначе предлагает перепроецировать в UTM).
        Возвращает путь к DEM для расчёта или None (отмена).
        """
        layer = QgsRasterLayer(dem_path, "dem_check")
        if not layer.isValid():
            QMessageBox.warning(self, "Ошибка",
                                "Файл DEM не читается как растровый слой!")
            return None

        # предупреждение о NoData — информативно, не блокирует
        if layer.dataProvider().sourceHasNoDataValue(1):
            QgsMessageLog.logMessage(
                "В DEM есть NoData-значения (например, водные области) — "
                "они будут исключены из расчётов.",
                PLUGIN_LOG_TAG, Qgis.Info)

        crs = layer.crs()
        if not crs.isGeographic():
            return dem_path

        # географическая CRS: уклон в градусах на градусной сетке
        # математически некорректен — предлагаем UTM
        extent = layer.extent()
        lon = extent.center().x()
        lat = extent.center().y()
        zone = int((lon + 180) / 6) + 1
        epsg = (32600 if lat >= 0 else 32700) + zone
        utm = QgsCoordinateReferenceSystem(f"EPSG:{epsg}")

        answer = QMessageBox.question(
            self, "Географическая система координат",
            f"DEM задан в градусах ({crs.authid()}). Расчёт уклона и "
            f"стока на градусной сетке даёт искажённые результаты.\n\n"
            f"Перепроецировать DEM в метрическую систему "
            f"{utm.authid()} (UTM зона {zone}) перед анализом?",
            _Yes | _No | _Cancel,
            _Yes)

        if answer == _Cancel:
            return None
        if answer == _No:
            return dem_path

        out = self.out_dir.text().strip()
        reproj = os.path.join(out, "reprojected_dem.tif")
        self.status_label.setText("Перепроецирование DEM...")
        try:
            processing.run("gdal:warpreproject", {
                'INPUT': dem_path, 'SOURCE_CRS': crs, 'TARGET_CRS': utm,
                'RESAMPLING': 1,  # bilinear — корректно для высот
                'OUTPUT': reproj})
        except Exception as e:
            QMessageBox.critical(self, "Ошибка",
                                 f"Не удалось перепроецировать DEM:\n{e}")
            return None
        return reproj

    # ---------------- запуск / отмена ----------------

    def cancel_running_task(self):
        if self.task and self.task.status() == QgsTask.Running:
            self.task.cancel()

    def on_run_clicked(self):
        if self.task and self.task.status() == QgsTask.Running:
            self.cancel_running_task()
            self.status_label.setText("Статус: Отмена...")
            return
        self.execute_analysis()

    def execute_analysis(self):
        dem = self.dem_path.text().strip()
        out = self.out_dir.text().strip()

        if not dem or not os.path.exists(dem):
            QMessageBox.warning(self, "Ошибка",
                                "Укажите существующий файл ЦМР (DEM)!")
            return
        if not out or not os.path.isdir(out):
            QMessageBox.warning(self, "Ошибка",
                                "Укажите корректную выходную папку!")
            return

        tasks = []
        if self.cb_hillshade.isChecked(): tasks.append("Hillshade")
        if self.cb_slope.isChecked(): tasks.append("Slope")
        if self.cb_aspect.isChecked(): tasks.append("Aspect")
        if self.cb_contours.isChecked(): tasks.append("Contours")
        if self.cb_runoff.isChecked(): tasks.append("Runoff")
        if self.cb_erosion.isChecked(): tasks.append("Erosion")

        if not tasks:
            QMessageBox.information(self, "Анализ",
                                    "Не выбран ни один расчетный слой!")
            return

        # проверка весов
        if "Erosion" in tasks:
            w_sum = (self.w_slope.value() + self.w_dry.value()
                     + self.w_wet.value() + self.w_prot.value())
            if abs(w_sum - 1.0) > 0.001:
                answer = QMessageBox.question(
                    self, "Веса модели",
                    f"Сумма весов = {w_sum:.2f}, а не 1.00.\n"
                    f"Нормировать веса автоматически?",
                    _Yes | _No, _Yes)
                if answer == _Yes and w_sum > 0:
                    for sb in (self.w_slope, self.w_dry,
                               self.w_wet, self.w_prot):
                        sb.setValue(round(sb.value() / w_sum, 2))

        protection = self.protection_path.text().strip()
        if protection and not os.path.exists(protection):
            QMessageBox.warning(self, "Ошибка",
                                "Указанный защитный растр не существует!")
            return

        dem_for_run = self.preflight_dem(dem)
        if dem_for_run is None:
            self.status_label.setText("Статус: Готов")
            return

        options = {
            'tasks': tasks,
            'contour_interval': self.spin_contour.value(),
            'hs_azimuth': self.spin_azimuth.value(),
            'hs_altitude': self.spin_altitude.value(),
            'hs_multi': self.cb_hs_multi.isChecked(),
            'flow_topology': FLOW_TOPOLOGIES[
                self.combo_flow.currentIndex()][1],
            'flow_k': self.spin_flow_k.value(),      # 0 = все направления
            'flow_time_steps': self.spin_time_steps.value(),  # 0 = до конца
            'w_slope': self.w_slope.value(),
            'w_dry': self.w_dry.value(),
            'w_wet': self.w_wet.value(),
            'w_prot': self.w_prot.value(),
            'protection_raster': protection or None,
        }

        self.task = AnalysisTask("Terrain & Hydrology Analysis",
                                 dem_for_run, out, options)
        self.task.progressChanged.connect(
            lambda p: self.progress_bar.setValue(int(p)))
        self.task.taskCompleted.connect(self.on_task_completed)
        self.task.taskTerminated.connect(self.on_task_terminated)

        self.btn_run.setText("Отменить")
        self.btn_run.setStyleSheet(
            "background-color: #d32f2f; color: white; "
            "font-weight: bold; padding: 5px 15px;")
        self.progress_bar.setVisible(True)
        self.progress_bar.setValue(0)
        self.status_label.setText("Статус: Расчёт в фоне...")

        QgsApplication.taskManager().addTask(self.task)

    # ---------------- завершение ----------------

    def _reset_ui(self):
        self.btn_run.setText("Запустить анализ")
        self.btn_run.setStyleSheet(
            "background-color: #2e7d32; color: white; "
            "font-weight: bold; padding: 5px 15px;")
        self.progress_bar.setVisible(False)

    def on_task_completed(self):
        task = self.task
        self._reset_ui()

        # загрузка слоёв — только в главном потоке (мы в нём)
        loaded = 0
        for filepath, layer_name, style_key in task.generated_layers:
            if filepath.endswith('.tif'):
                layer = QgsRasterLayer(filepath, layer_name)
            else:
                layer = QgsVectorLayer(filepath, layer_name, "ogr")
            if layer.isValid():
                apply_style(layer, style_key)
                QgsProject.instance().addMapLayer(layer)
                loaded += 1
            else:
                QgsMessageLog.logMessage(
                    f"Слой '{layer_name}' не удалось загрузить "
                    f"из {filepath}.", PLUGIN_LOG_TAG, Qgis.Warning)

        self.status_label.setText("Статус: Завершено успешно!")
        msg = (f"Расчет окончен! Загружено слоёв: {loaded}.\n"
               f"Файлы сохранены в:\n{self.out_dir.text().strip()}")
        if task.warnings:
            msg += "\n\nЗамечания:\n• " + "\n• ".join(task.warnings)
        QMessageBox.information(self, "Успех", msg)
        self.task = None

    def on_task_terminated(self):
        task = self.task
        self._reset_ui()
        if task and task.exception:
            self.status_label.setText("Статус: Ошибка")
            QMessageBox.critical(
                self, "Критическая ошибка",
                f"Ошибка во время геообработки растров:\n{task.exception}")
        else:
            self.status_label.setText("Статус: Отменено")
        self.task = None
